---------------------------------------------------------------------------
-- FlightDash V5 Widget 
-- EdgeTX 2.11+
---------------------------------------------------------------------------

local name = "fltDashP2"

local PURPLE = lcd.RGB(149, 66, 245)
local BROWN = lcd.RGB(79, 54, 39)
local PINK = lcd.RGB(206, 126, 252)
local CYAN = lcd.RGB(58, 242, 242)
local LIGHTBLUE = lcd.RGB(25, 175, 255)

local tlmColor = BLUE

local trim1 = 0
local trim2 = 0
local trim3 = 0
local trim4 = 0
---------------------------------------------------------------------------
-- OPTIONS
---------------------------------------------------------------------------

local options = {
  { "Motor Switch",     SWITCH, 0 },
  { "Motor On Text",    STRING, "MOTOR ON" },
  { "Motor Off Text",   STRING, "MOTOR OFF" },
  { "Rx Signal", SOURCE, 0 },
  { "Rx Qty",    SOURCE, 0 },
  { "Rx Batt",   SOURCE, 0 }
}

---------------------------------------------------------------------------
-- IMAGE HELPERS
---------------------------------------------------------------------------
local bm = nil

-- Slideshow variables
local imageList = {}
local currentImageIndex = 1
local lastImageChange = 0
local SLIDE_INTERVAL = 800

local function pngFilename(imgName)
  if not imgName or imgName == "" then return nil end

  if not string.match(imgName, "%.png$") then
    imgName = imgName .. ".png"
  end

  return imgName
end

local function fileExists(path)
  local f = io.open(path, "r")

  if f then
    io.close(f)
    return true
  end

  return false
end

local function loadImage(imgName)
  bm = nil

  if not imgName or imgName == "" then return false end

  local filename = pngFilename(imgName)
  local path = "/IMAGES/" .. filename

  local ok, img = pcall(Bitmap.open, path)

  if ok and img then
    bm = img
    return true
  end

  return false
end

local function buildImageList(modelName)

  imageList = {}

  -- MAIN IMAGE
  local mainPath = "/IMAGES/" .. modelName .. ".png"

  if fileExists(mainPath) then
    table.insert(imageList, modelName)
  end

  -- SLIDESHOW IMAGES
  for i = 1, 20 do

    local imgName = modelName .. "_" .. i
    local imgPath = "/IMAGES/" .. imgName .. ".png"

    if fileExists(imgPath) then
      table.insert(imageList, imgName)
    else
      break
    end
  end
end

---------------------------------------------------------------------------
-- CREATE
---------------------------------------------------------------------------

local function create(zone, opts)

  local w = { zone = zone, options = opts or {} }

  local modelName = model.getInfo().name

  buildImageList(modelName)

  currentImageIndex = 1
  lastImageChange = getTime()

  if #imageList > 0 then
    loadImage(imageList[currentImageIndex])
  end

  return w
end

---------------------------------------------------------------------------
-- UPDATE
---------------------------------------------------------------------------
local function update(widget, opts)
  widget.options = opts
end

---------------------------------------------------------------------------
-- SOURCE LABEL FUNCTION
---------------------------------------------------------------------------
local function sourceLabel(src, fallback)
  if src ~= 0 then
    local info = getSourceInfo(src)
    if info and info.name then
      return info.name
    end
  end
  return fallback
end

---------------------------------------------------------------------------
-- BATTERY ICON
---------------------------------------------------------------------------
local function drawBatteryIcon(x, y, w, h, percent, color)
  lcd.drawRectangle(x, y, w, h, WHITE)
  lcd.drawFilledRectangle(x + w, y + h / 3, 4, h / 3, WHITE)
  lcd.drawFilledRectangle(x + 1, y + 1, (w - 2) * percent, h - 2, color)
end 
---------------------------------------------------------------------------
-- REFRESH
---------------------------------------------------------------------------

local function refresh(widget)
  local z   = widget.zone
  local opt = widget.options

  trim1 = getValue("trim-ail") or 0
  trim2 = getValue("trim-ele") or 0
  trim3 = getValue("trim-thr") or 0
  trim4 = getValue("trim-rud") or 0

  ---------------------------------------------------------------------------
  -- SLIDESHOW
  ---------------------------------------------------------------------------

  local now = getTime()

  if #imageList > 1 then

    if now - lastImageChange >= SLIDE_INTERVAL then

      lastImageChange = now

      currentImageIndex = currentImageIndex + 1

      if currentImageIndex > #imageList then
        currentImageIndex = 1
      end

      loadImage(imageList[currentImageIndex])
    end
  end

  lcd.drawFilledRectangle(z.x, z.y, z.w, z.h, BLACK)
  lcd.drawFilledRectangle(z.x, z.y, z.w, 45, ORANGE)
  
  ---------------------------------------------------------------------------
  -- MOTOR / FM
  ---------------------------------------------------------------------------
  local rssVal  = (opt["Rx Signal"] ~= 0 and getValue(opt["Rx Signal"])) or 0
  
  local motorOn = (opt["Motor Switch"] ~= 0 and getSwitchValue(opt["Motor Switch"])) == true
  local motorOnText = opt["Motor On Text"] or "MOTOR ON"
  local motorOffText = opt["Motor Off Text"] or "MOTOR OFF"
  local fm      = getFlightMode() or 0

  local texts = {
  motorOn and motorOnText or motorOffText,
  "FM" .. fm
  }

  local motorColor = motorOn and DARKRED or WHITE

  lcd.drawText((z.x + (z.w / 11 * 3)), z.y + 8, texts[1], CENTER + MIDSIZE + ((rssVal ~= 0) and motorColor or WHITE))
  lcd.drawText((z.x + (z.w / 11 * 6)), z.y + 8, texts[2], CENTER + MIDSIZE + ((rssVal ~= 0) and DARKRED or WHITE))
  
  ---------------------------------------------------------------------------
  -- TX VOLTAGE
  ---------------------------------------------------------------------------
  local txV = getValue("tx-voltage") or 0

  local txvColor
  if txV > 7.3 then
    txvColor = GREEN
  else 
    txvColor = DARKRED
  end

  lcd.drawText((z.x + (z.w / 11 * 8)), z.y + 8, string.format("Tx:%.1fV", txV), CENTER + MIDSIZE + txvColor)
  ---------------------------------------------------------------------------
  -- TX TIME
  ---------------------------------------------------------------------------
  local dt = getDateTime()
  local months = { "Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec" }

  lcd.drawText((z.x + (z.w / 11 * 10)), z.y + 4, string.format("%d %s", dt.day, months[dt.mon]), CENTER + WHITE)
  lcd.drawText((z.x + (z.w / 11 * 10)), z.y + 22, string.format("%02d:%02d", dt.hour, dt.min), CENTER + WHITE)

  ---------------------------------------------------------------------------
  -- TELEMETRY RECTANGLES
  ---------------------------------------------------------------------------
  local trw = z.w / 3
  local trh = z.h / 8

  local trx = z.x + 20
  local ry1 = z.y + (z.h / 10 * 4)
  local ry2 = z.y + (z.h / 10 * 6)
  local ry3 = z.y + (z.h / 10 * 8)

  lcd.drawFilledRectangle(trx, ry2, trw, trh, ((rssVal ~= 0) and LIGHTGREY or BLACK))
  lcd.drawFilledRectangle(trx, ry3, trw, trh, ((rssVal ~= 0) and LIGHTGREY or BLACK))

  lcd.drawRectangle(trx, ry2, trw, trh, ORANGE)
  lcd.drawRectangle(trx, ry3, trw, trh, ORANGE)

  ---------------------------------------------------------------------------
  -- TIMER RECTANGLE
  ---------------------------------------------------------------------------
  local timer = model.getTimer(0)
  local timeLeft = timer.value or 0
  local maxTime  = timer.start or 1
  local percent  = math.max(0, math.min(1, timeLeft / maxTime))

  if rssVal ~= 0 then
    local barColor

    if percent <= 0.15 then
      barColor = RED
    elseif percent <= 0.5 then
      barColor = YELLOW
    else
      barColor = GREEN
    end

    lcd.drawFilledRectangle(trx, ry1, trw * percent , trh, barColor)
  end

  lcd.drawRectangle(trx, ry1, trw, trh, ORANGE)  

  local text1X = trx + trw / 2
  local text1Y = ry1 + trh / 4
  lcd.drawText(text1X, text1Y, string.format("%02d:%02d", math.floor(timeLeft / 60), timeLeft % 60), CENTER + ((rssVal ~= 0) and tlmColor or WHITE))
  ---------------------------------------------------------------------------
  -- PICTURE RECTANGLE
  ---------------------------------------------------------------------------
  local prw = z.w * 0.50

  local pry = ry1
  local prh = (ry3 + trh) - ry1

  local prx = z.x + (z.w - prw) * 0.9
  
  -- MODEL NAME
  lcd.drawText(prx + prw / 2, z.y + (z.h / 10 * 2), model.getInfo().name or "MODEL", CENTER + DBLSIZE + ((rssVal ~= 0) and tlmColor or WHITE))

  --SCALING THE IMAGE TO FIT THE PICTURE RECTANGE
  if bm then

    local bw, bh = Bitmap.getSize(bm)

    -- Available drawing area
    local aw = prw
    local ah = prh

    -- Width/height ratios
    local wr = aw / bw
    local hr = ah / bh

    local scl = 100
    local dx = prx
    local dy = pry

    -- Keep aspect ratio
    if wr < hr then
        scl = math.floor(wr * 100)

        local scaledH = bh * wr
        dy = pry + (prh - scaledH) / 2
    else
        scl = math.floor(hr * 100)

        local scaledW = bw * hr
        dx = prx + (prw - scaledW) / 2
    end
     
    lcd.drawBitmap(bm, dx, dy, scl)
  else
    lcd.drawText(prx + prw / 2, pry + prh / 4, "MODEL IMAGE", CENTER + MIDSIZE + ((rssVal ~= 0) and tlmColor or WHITE)) 
    lcd.drawText(prx + prw / 2, pry + prh / 2, "NOT FOUND", CENTER + MIDSIZE + ((rssVal ~= 0) and tlmColor or WHITE)) 
  end

    lcd.drawRectangle(prx, pry, prw, prh, ORANGE)

  ---------------------------------------------------------------------------
  -- OPTIONS / TELEMTERY VALUES
  ---------------------------------------------------------------------------
  local rqtyVal = (opt["Rx Qty"] ~= 0 and getValue(opt["Rx Qty"])) or 0
  local vbatVal  = (opt["Rx Batt"]  ~= 0 and getValue(opt["Rx Batt"]))  or 0

  local text2X = trx + trw / 2
  local text2Y = ry2 + trh / 4

  local text3X = trx + trw / 2
  local text3Y = ry3 + trh / 4

  lcd.drawText(text2X, text2Y, string.format(": %d%%", rqtyVal), LEFT + ((rssVal ~= 0) and tlmColor or WHITE))
  lcd.drawText(text2X, text2Y, sourceLabel(opt["Rx Qty"], "RQly"), RIGHT + ((rssVal ~= 0) and tlmColor or WHITE))

  lcd.drawText(text3X, text3Y, string.format(": %ddB", rssVal), LEFT + ((rssVal ~= 0) and tlmColor or WHITE))
  lcd.drawText(text3X, text3Y, sourceLabel(opt["Rx Signal"], "1RSS"), RIGHT + ((rssVal ~= 0) and tlmColor or WHITE))

  -------------------------------------------------------------------------
  -- RX BATTERY
  -------------------------------------------------------------------------

  local detectedCells
  if cellsVal and cellsVal >= 3 and cellsVal <= 12 then
    detectedCells = cellsVal
  end

  local cells = detectedCells or 1
  local vPerCell = (cells > 0 and vbatVal > 0) and (vbatVal / cells) or 0

  -- VBAT Voltage → Percentage
  local vMin = 3.3
  local vMax = 4.2

  local vPercent = (vPerCell - vMin) / (vMax - vMin)
  vPercent = math.max(0, math.min(1, vPercent))

  -- VBAT Color + flash logic
  local vColor = GREEN
  local flash = false

  if vPercent <= 0.25 then
    vColor = RED
    flash = true
  elseif vPercent <= 0.50 then
    vColor = YELLOW
  end

  if flash and (getTime() % 20 < 10) then
    vColor = BLACK
  end

  -- DRAW BATTERY ICON
  local battW = z.w / 3
  local battH = z.h / 8 * 1
  local battX = z.x + 20
  local battY = z.y + (z.h / 10 * 2)

  drawBatteryIcon(battX,battY,battW,battH,vPercent,vColor)

  local textX = battX + battW / 2
  local textY = battY + 2
  local vbatColor = (rssVal ~= 0) and tlmColor or WHITE

  lcd.drawText(textX, textY, string.format("%.2fV", vbatVal), CENTER + vbatColor + BOLD)

  if detectedCells and vPerCell > 0 then
    lcd.drawText(textX, textY + 14, string.format("%.2fV / %dS", vPerCell, detectedCells), CENTER + WHITE)
  end

  -------------------------------------------------------------------------
  -- TRIMS
  -------------------------------------------------------------------------
  local function drawTrimBar(x, y, w, h, value, vertical)

  lcd.drawRectangle(x, y, w, h, ORANGE)
  local percent = (value + 1000) / 2000

  percent = math.max(0, math.min(1, percent))

  if vertical then

    local markerH = 8

    -- CENTER MARKER 
    local centerY = y + (h - markerH) / 2
    lcd.drawFilledRectangle(x + 1,centerY,w - 2,markerH,ORANGE)

    -- MOVING MARKER
    local markerY = y + (h - markerH) * (1 - percent)
    lcd.drawFilledRectangle(x + 1,markerY,w - 2,markerH,CYAN)

  else

    local markerW = 8
    
    -- CENTER MARKER 
    local centerX = x + (w - markerW) / 2
    lcd.drawFilledRectangle(centerX,y + 1,markerW,h - 2,ORANGE)

    -- MOVING MARKER
    local markerX = x + (w - markerW) * percent
    lcd.drawFilledRectangle(markerX,y + 1,markerW,h - 2,CYAN)
  end
end

  ---------------------------------------------------------------------------
  -- DRAW TRIM BARS
  ---------------------------------------------------------------------------

  local trimThickness = 6
  local hTrimWidth = z.w * 0.38

  -- LEFT VERTICAL = CH3
  drawTrimBar(z.x + 4,z.y + 55,trimThickness,z.h - 65,trim3,true)
 
  -- RIGHT VERTICAL = CH2
  drawTrimBar(z.x + z.w - trimThickness - 4,z.y + 55,trimThickness,z.h - 65,trim2,true)

  -- LEFT HORIZONTAL = CH4
  drawTrimBar(z.x + 15,z.y + z.h - 10,hTrimWidth,trimThickness,trim4,false)

  -- RIGHT HORIZONTAL = CH1
  drawTrimBar(z.x + z.w - hTrimWidth - 15,z.y + z.h - 10,hTrimWidth,trimThickness,trim1,false)

end
---------------------------------------------------------------------------

return {
  name = name,
  create = create,
  refresh = refresh,
  update = update,
  options = options
}
